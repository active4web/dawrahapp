/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'zh-cn', {
	embeddingInProgress: '正在尝试嵌入粘贴的 URL 里的媒体内容...',
	embeddingFailed: '此 URL 无法自动嵌入媒体内容。'
} );
